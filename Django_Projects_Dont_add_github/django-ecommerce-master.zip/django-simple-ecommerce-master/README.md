# Django Simple E-commerce

This is a simple E-commerce website built with Django. It contains all the essentials for adding products and capturing payments
online.

This project is part of a course on [https://learn.justdjango.com](JustDjango).
