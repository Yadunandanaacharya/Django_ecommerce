

import os
import sys

from django.conf.urls import url
from django.contrib import admin

from firstApp import views as v1

from django.urls import path
import views
# from firstApp im
urlpatterns = [
    # path('',views.home, name = 'home')
    url('',v1.home,{})
]