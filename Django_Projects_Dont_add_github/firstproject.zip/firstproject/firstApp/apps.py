from django.apps import AppConfig


class FirstappConfig(AppConfig):
    name = 'firstApp'
